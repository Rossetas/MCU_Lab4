# README

This example is the same as fancy\_blink except that it uses the
systick timer to generate time accurate delays. Shows how to set
up the systick timer to create an interrupt every millisecond and
how to write a delay routine (msleep) that can then delay for a
specific number of milliseconds.

## Board connections

*none required*
