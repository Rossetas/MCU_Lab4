# README

This example randomly blinks the GREEN LED on the ST STM32F4DISCOVERY eval
board.

## Board connections

*none required*

