# README

This example randomly blinks the GREEN LED on the ST STM32F429IDISCOVERY eval
board.

## Board connections

*none required*

