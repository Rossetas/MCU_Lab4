# README

This is a PWM based LED fading example using libopencm3.

It's intended for the ST STM32-based
[MB525 eval board](http://www.st.com/stonline/products/literature/um/13472.htm for details).

