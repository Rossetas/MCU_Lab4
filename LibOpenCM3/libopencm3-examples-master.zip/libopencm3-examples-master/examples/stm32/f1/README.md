Examples in these directories are not _only_ for the board listed, they are
simply preconfigured for those boards.  If you do not find an example of the
peripheral you want to use listed for your board, please look at the other
boards.  The differences between boards for the examples is normally only
LEDs and buttons on different pins, and different memory sizes.
