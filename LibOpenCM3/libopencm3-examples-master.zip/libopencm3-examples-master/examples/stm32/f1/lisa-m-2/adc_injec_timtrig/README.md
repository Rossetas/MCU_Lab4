# README

This is a simple example that sends the value read out from the
temperature sensor ADC channel of the STM32 to the USART2.

This example uses a timer trigger to automatically sample the adc channel.

The terminal settings for the receiving device/PC are 115200 8n1.

