# README

This example program sends some characters on USART1.
Afterwards it connects to an STTS75 sensor (ST LM75 compatible)
at adress A0/1/2=0 and sets reverse polarity, 26 degree Tos and Thyst.

It reads out the temperature and submits the temperature over USART1 in
binary format (ASCII 0/1).

The terminal settings for the receiving device/PC are 115200 8n1.

