# README

This program demonstrates a little DMA MEM2MEM transfer. A string is sent out
to USART1 and afterwards copied by DMA to another memory location. To check
if the transfer was successful we send the destination string also out to
USART1.

The terminal settings for the receiving device/PC are 115200 8n1.

