# README

This example blinks the green LED on the ST STM32VLDISCOVERY eval board.

When you press the 'USER' button, the blinking is slower.

