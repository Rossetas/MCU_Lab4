# README

This example implements a USB Human Interface Device (HID)
to demonstrate the use of the USB device stack.

