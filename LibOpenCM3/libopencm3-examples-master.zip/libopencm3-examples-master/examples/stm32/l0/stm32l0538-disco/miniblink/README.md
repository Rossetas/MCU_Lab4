# README

This is the smallest-possible example program using libopencm3.

It's intended for the ST STM32L053-DISCOVERY eval board. It should blink
the red/green LEDs on the board in turn.

