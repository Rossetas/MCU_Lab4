This demonstrates some basics on the L476G disco board.

* printf via usart2 to the attached stlink virtual com port. 115200@8n1
* pll configuration from hsi
* flash wait state configuration
* basic led blinking
* exti interrupts for buttons
* simple timer usage.
