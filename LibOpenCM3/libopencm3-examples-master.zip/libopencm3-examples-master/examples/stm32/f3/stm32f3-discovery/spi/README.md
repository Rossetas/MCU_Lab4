# README

SPI example reading from the stm32f3discovery gyroscope.


