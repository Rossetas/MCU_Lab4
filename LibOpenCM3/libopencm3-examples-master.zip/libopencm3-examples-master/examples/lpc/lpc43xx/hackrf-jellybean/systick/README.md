# README

This program exercises the SysTick Interrupt of ARM CortexM4 on Jellybean's LPC43xx.
It also enable Cycle Counter to be used for accurate delay independant from Clock Frequency.
The Demo Use Cycle Counter and SysTick Interrupt to compute number of cycles executed per second.
The result is LED1/2 & 3 Blink with an accurate 1s Period (using SysTick) (Checked visualy and with Oscilloscope).
